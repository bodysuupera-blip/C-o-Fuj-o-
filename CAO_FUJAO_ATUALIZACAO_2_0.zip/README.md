# Cão Fujão — código-fonte independente

Este projeto foi reconstruído a partir do APK enviado nesta conversa. Ele contém o jogo recuperado
(tela de boas-vindas, regras, tabuleiro, movimentação, 500 fases, moedas, vidas, loja interna,
sons e convite), os arquivos de imagem e o projeto Android nativo.

## Estrutura

- `app/src/main/assets/index.html` — código HTML, CSS e JavaScript do jogo.
- `app/src/main/assets/intro.png` — arte original da tela inicial extraída do APK.
- `app/src/main/java/com/mentex/caofujao/MainActivity.java` — aplicativo Android, WebView,
  compartilhamento e integração de compras Google Play Billing.
- `app/src/main/res/` — ícones recuperados do APK.
- `app/build.gradle` — configuração do aplicativo e dependência Google Play Billing.

## Como abrir e gerar o APK

1. Extraia este ZIP em uma pasta.
2. Abra a pasta `CAO_FUJAO_FONTE_INDEPENDENTE` no Android Studio.
3. Aguarde a sincronização do Gradle (JDK 17 e Android SDK 35).
4. Para testar, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

O projeto não depende dos ZIPs anteriores do jogo. O Android Studio/Gradle ainda precisa baixar
as ferramentas e a biblioteca oficial do Google Play Billing na primeira compilação.

## Compras pela Google Play

O código nativo contém a integração de cobrança e espera estes IDs de produtos do tipo
**produto no app / compra única** no Google Play Console:

- `coins_500`
- `coins_1500`
- `coins_4000`
- `coins_10000`

Os produtos precisam ser cadastrados e ativados no Play Console, e a versão precisa ser enviada
para uma faixa de teste interno/fechado para testar compras reais. A disponibilidade de compra
também depende de uma conta de testador e da configuração da ficha do aplicativo.

## Observação importante sobre a reconstrução

O arquivo recebido era um APK compilado, não o projeto original. Por isso, o código-fonte Android
foi recriado para hospedar o jogo recuperado. O HTML/CSS/JavaScript e as imagens do jogo foram
extraídos do APK; os arquivos originais de projeto e histórico de desenvolvimento não estavam
dentro dele.


## Atualização de itens (2.0)
Consulte `ATUALIZACAO_2_0.txt`. Os itens agora têm efeitos funcionais no jogo. A recompensa por anúncio requer configuração real do Google AdMob antes de funcionar em produção.
