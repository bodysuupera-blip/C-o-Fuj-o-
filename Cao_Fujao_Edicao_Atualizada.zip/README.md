# Cão Fujão — Edição Renovada 🐾

Projeto Android (Java + WebView) com jogo HTML5.

## Atualizações desta edição
- Interface inicial e loja renovadas, com identidade visual Cão Fujão.
- 5 vidas grátis no início (migração de saves antigos para 5 vidas).
- Tênis turbo: o cão se movimenta apenas a cada dois movimentos do jogador.
- Pacote de coração: compra adiciona 3 vidas e pode ser comprado novamente.
- Chapéu: concede +10 segundos na próxima captura.
- Coleira dourada: captura automaticamente quando o jogador fica a uma casa do cão.
- Escudo: protege contra uma derrota por tempo esgotado.
- Cronômetro de captura e opção de recompensa por anúncio na interface.
- Controles direcionais corrigidos.
- Progresso salvo localmente no aparelho.

## Importante sobre anúncios
O botão “Ver anúncio — ganhar 1 vida” está preparado visualmente, mas a recompensa real depende da integração com Google AdMob e de um bloco de anúncio recompensado válido. O projeto não simula a exibição de anúncio nem concede vida sem validação da recompensa.

## Gerar APK
1. Abra a pasta no Android Studio.
2. Use JDK 17 e Android SDK 35.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
