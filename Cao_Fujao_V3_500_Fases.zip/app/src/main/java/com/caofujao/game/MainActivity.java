package com.caofujao.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.util.Log;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.android.billingclient.api.BillingFlowParams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity implements PurchasesUpdatedListener {
    private static final String TAG = "CaoFujaoBilling";
    private WebView web;
    private BillingClient billingClient;
    private final Map<String, ProductDetails> products = new HashMap<>();
    private final Map<String, Integer> coinAmounts = new HashMap<>();
    private final Map<String, String> offerTokens = new HashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,27,55));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,27,55));
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void share(String message) {
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(send, "Convidar amigos"));
                });
            }
            @JavascriptInterface public void loadProducts() {
                runOnUiThread(() -> connectBillingAndLoadProducts());
            }
            @JavascriptInterface public void buyCoins(String productId) {
                runOnUiThread(() -> launchCoinPurchase(productId));
            }
        }, "AndroidShare");
        // Billing usa uma ponte separada para as compras da Google Play.
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void loadProducts() {
                runOnUiThread(() -> connectBillingAndLoadProducts());
            }
            @JavascriptInterface public void buyCoins(String productId) {
                runOnUiThread(() -> launchCoinPurchase(productId));
            }
        }, "AndroidBilling");

        coinAmounts.put("coins_300", 300);
        coinAmounts.put("coins_1000", 1000);
        coinAmounts.put("coins_2500", 2500);
        coinAmounts.put("coins_5000", 5000);
        coinAmounts.put("coins_10000", 10000);

        billingClient = BillingClient.newBuilder(this)
                .setListener(this)
                .enablePendingPurchases(com.android.billingclient.api.PendingPurchasesParams.newBuilder()
                        .enableOneTimeProducts().build())
                .build();

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void connectBillingAndLoadProducts() {
        if (billingClient == null) return;
        if (billingClient.isReady()) {
            queryCoinProducts();
            return;
        }
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryCoinProducts();
                    recoverPurchases();
                } else {
                    js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Google Play indisponível: " + safe(result.getDebugMessage()) + "');");
                }
            }
            @Override public void onBillingServiceDisconnected() {
                Log.w(TAG, "Billing service disconnected");
            }
        });
    }

    private void queryCoinProducts() {
        List<QueryProductDetailsParams.Product> productList = new ArrayList<>();
        for (String id : coinAmounts.keySet()) {
            productList.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build());
        }
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(productList).build();
        billingClient.queryProductDetailsAsync(params, (result, queryResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Não foi possível carregar os pacotes da Google Play.');");
                return;
            }
            products.clear();
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            for (ProductDetails detail : queryResult.getProductDetailsList()) {
                products.put(detail.getProductId(), detail);
                List<ProductDetails.OneTimePurchaseOfferDetails> offers = detail.getOneTimePurchaseOfferDetailsList();
                ProductDetails.OneTimePurchaseOfferDetails offer = (offers == null || offers.isEmpty()) ? null : offers.get(0);
                if (offer != null && offer.getOfferToken() != null) offerTokens.put(detail.getProductId(), offer.getOfferToken());
                String price = offer == null ? "Preço na Google Play" : offer.getFormattedPrice();
                if (!first) json.append(',');
                first = false;
                json.append("{\"id\":\"").append(detail.getProductId())
                        .append("\",\"price\":\"").append(jsonEscape(price)).append("\"}");
            }
            json.append(']');
            js("window.onPlayBillingProducts && window.onPlayBillingProducts('" + json.toString() + "');");
        });
    }

    private void launchCoinPurchase(String productId) {
        if (!coinAmounts.containsKey(productId)) {
            js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Pacote de moedas inválido.');");
            return;
        }
        if (!billingClient.isReady()) {
            connectBillingAndLoadProducts();
            js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Conectando à Google Play. Tente novamente em instantes.');");
            return;
        }
        ProductDetails detail = products.get(productId);
        if (detail == null) {
            queryCoinProducts();
            js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Produto ainda não carregado. Verifique se foi cadastrado na Play Console.');");
            return;
        }
        BillingFlowParams.ProductDetailsParams.Builder detailBuilder = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(detail);
        String offerToken = offerTokens.get(productId);
        if (offerToken != null && !offerToken.isEmpty()) detailBuilder.setOfferToken(offerToken);
        BillingFlowParams.ProductDetailsParams productParams = detailBuilder.build();
        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Arrays.asList(productParams)).build();
        BillingResult result = billingClient.launchBillingFlow(this, flowParams);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Não foi possível iniciar a compra.');");
        }
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) processPurchase(purchase);
        } else if (result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Compra cancelada.');");
        } else if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Falha na compra pela Google Play.');");
        }
    }

    private void recoverPurchases() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP).build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                for (Purchase purchase : purchases) processPurchase(purchase);
            }
        });
    }

    private void processPurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        String productId = purchase.getProducts().isEmpty() ? "" : purchase.getProducts().get(0);
        Integer amount = coinAmounts.get(productId);
        if (amount == null) return;
        ConsumeParams params = ConsumeParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken()).build();
        billingClient.consumeAsync(params, (result, token) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                js("window.onPlayBillingResult && window.onPlayBillingResult(true,'Compra aprovada! +" + amount + " moedas adicionadas.'," + amount + ");");
            } else {
                js("window.onPlayBillingResult && window.onPlayBillingResult(false,'Compra realizada, mas não foi possível confirmar o consumo. Entre em contato com o suporte.');");
            }
        });
    }

    private void js(String script) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(script, null); });
    }
    private String safe(String value) { return value == null ? "erro" : value.replace("'", ""); }
    private String jsonEscape(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("\"", "\\\"").replace("'", "\\'");
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (billingClient != null && billingClient.isReady()) billingClient.endConnection();
        super.onDestroy();
    }
}
