# CÃO FUJÃO – versão 3.0

Projeto Android WebView com 500 fases, dificuldade progressiva e compras de moedas pela Google Play.

## Mudanças desta versão
- 500 fases (progresso até 500).
- Começo mais fácil: nos primeiros 25 níveis, o cão se move em turnos alternados; depois acelera gradualmente até 4 movimentos por jogada.
- Obstáculos, tempo e limite de jogadas aumentam de dificuldade progressivamente.
- Botão principal e botões de ação maiores.
- Saldo inicial de moedas zerado; migração da versão anterior desconta as 100 moedas iniciais antigas.
- Removidos os textos “Nova edição” e “Edição renovada”.
- Loja com pacotes de 300, 1.000, 2.500, 5.000 e 10.000 moedas via Google Play Billing 8.0.0.

## Configurar compras na Google Play Console
Antes de as compras funcionarem em uma versão publicada ou faixa de teste interno:
1. Crie cinco produtos únicos (produtos no app) com estes IDs exatos:
   - `coins_300` – concede 300 moedas
   - `coins_1000` – concede 1.000 moedas
   - `coins_2500` – concede 2.500 moedas
   - `coins_5000` – concede 5.000 moedas
   - `coins_10000` – concede 10.000 moedas
2. Defina o preço de cada produto na Play Console. O app busca e mostra o preço localizado retornado pela Google Play.
3. Envie uma versão assinada do app para uma faixa de teste interno e teste com uma conta licenciada/testadora.
4. O `applicationId` precisa permanecer `com.caofujao.game` para corresponder ao app cadastrado na Play Console.

A compra usa o fluxo Google Play Billing e consome os produtos para permitir compras repetidas. Para lançamento comercial, recomenda-se validar os tokens de compra em um servidor seguro antes de creditar moedas; esta amostra credita após a confirmação/consumo no cliente e não inclui servidor de validação.

## Compilação
- JDK 17
- Android Gradle Plugin 8.6.1
- Gradle 8.9
- Android SDK 35

Use o workflow GitHub Actions que já compilou a versão anterior; ele localiza `settings.gradle` e executa `assembleDebug`.
